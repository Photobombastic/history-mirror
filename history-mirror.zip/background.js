chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "PAGE_SUMMARY") {
    console.log("Page summary received:", message.text.slice(0, 80));
    // Add popup or fetch logic here later
  }
});
