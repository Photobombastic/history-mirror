const API_KEY = "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";

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'FETCH_COMPARISON') {
    fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-4",
        messages: [
          { role: "system", content: "Summarize the historical context or parallels for this modern news story." },
          { role: "user", content: `${message.headline}\n\n${message.body}` }
        ],
        max_tokens: 150
      })
    })
    .then(res => res.json())
    .then(data => {
      console.log("🧠 OpenAI result:", data);
      sendResponse({ summary: data.choices?.[0]?.message?.content || "No summary found." });
    })
    .catch(err => {
      console.error("OpenAI error:", err);
      sendResponse({ summary: "Error fetching history insight." });
    });
    return true;
  }
});
